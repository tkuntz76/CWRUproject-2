DROP DATABASE IF EXISTS news_search_db;
CREATE DATABASE news_search_db;
